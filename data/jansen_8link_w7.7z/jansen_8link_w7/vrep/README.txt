1. fixed base has two shafts:

one extra dummy to triangle part

2. triangle part has two shafts:

one extra dummy to link7 part

3. link8 has two shafts:

one to link1 part

one to link7 part

