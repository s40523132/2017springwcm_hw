from distutils.core import setup

setup(name='pygear',
      version='0.24',
      py_modules=['pygear'],
      )
