.. -*- mode: rst -*-

People
------

TensorLy is developed by a group of Researchers from Imperial College London:

- `Jean Kossaifi <http://jeankossaifi.github.io>`_
- `Yannis Panagakis <http://ibug.doc.ic.ac.uk/people/ypanagakis>`_


