# 0.1.4

- Added Robust Tensor PCA
