=============
Documentation
=============

Documentation is a crutial part of this library.

All functions and classes should come with useful docstrings. For these, we use the numpy style docstrings.

In particular, use single backticks for variable's names.
Double backticks are used for inline code. For blocks of code, use double
colons, leave a white line and indent said lines of code.
