This folder contain the sphinx extensions used to build the documentation.

They are only included to not add dependencies, please refer to the original package for any information.
