:mod:`{{module}}`.{{objname}}
{{ underline }}==============

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
   :members:

.. include:: {{module}}.{{objname}}.examples

.. raw:: html

    <div class="clearer"></div>
