.. _user_guide:

User guide
==========

.. toctree::
   :numbered:

   tensor_basics.rst
   tensor_decomposition.rst
   tensor_regression.rst
