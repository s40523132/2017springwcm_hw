Gallery of examples
===================

.. contents:: **Contents**
    :local:
    :depth: 1

General examples
----------------

Examples of tensor usage.
