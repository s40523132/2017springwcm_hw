"""
Module to sample random tensors
"""

from .base import cp_tensor, tucker_tensor, check_random_state
